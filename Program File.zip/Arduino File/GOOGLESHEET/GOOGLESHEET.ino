function doGet(e){

  var ss = SpreadsheetApp.getActiveSpreadsheet();

  var students = ss.getSheetByName("student");
  var attendance = ss.getSheetByName("ATTENDANCE");
  var report = ss.getSheetByName("REPORT");

  // -------- CHECK ATTENDANCE REQUEST --------
 if(e.parameter.check=="1"){

  var reportData = report.getDataRange().getValues();
  var studentData = students.getDataRange().getValues();

  var result = [];

 for(var i=1;i<reportData.length;i++){

  var roll = reportData[i][1];
  var name = reportData[i][0];
  var percent = parseFloat(reportData[i][4]);

  if(percent < 75){

    for(var j=1;j<studentData.length;j++){

      if(studentData[j][1] == name){

        var phone = studentData[j][3];

       result.push(name + "," + phone + "," + Number(percent).toFixed(2));

      }

    }

  }

}

  if(result.length > 0){

    return ContentService.createTextOutput(result.join(";"));

  }

  return ContentService.createTextOutput("OK");

}

  // -------- NORMAL ATTENDANCE SAVE --------

  var uid = e.parameter.uid;
  var status = e.parameter.status;
  var classNum = parseInt(e.parameter.class);

  var studentData = students.getDataRange().getValues();

  var roll="";
  var name="";

  for(var i=1;i<studentData.length;i++){

    if(studentData[i][0].toString().toLowerCase()==uid){

      roll = studentData[i][1];
      name = studentData[i][2];

      break;

    }

  }

  // SUBJECT MAPPING
  var subject="";

  if(classNum==1) subject="PRP";
  else if(classNum==2) subject="SS";
  else if(classNum==3) subject="LIC";
  else if(classNum==4) subject="TLW";
  else if(classNum==5) subject="ACS";
  else if(classNum==6) subject="DT";
  else if(classNum==7) subject="PRP";
  else if(classNum==8) subject="SS";

  var time = Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone(),
    "HH:mm:ss"
  );

  attendance.appendRow([uid,roll,name,subject,status,classNum,time]);

  updateReport();
  updateSubjectReport();

  return ContentService.createTextOutput("Attendance Saved");

}



function updateReport(){

  var ss = SpreadsheetApp.getActiveSpreadsheet();

  var attendance = ss.getSheetByName("ATTENDANCE");
  var report = ss.getSheetByName("REPORT");

  var data = attendance.getDataRange().getValues();

  var students = {};

  for(var i=1;i<data.length;i++){

    var roll = data[i][2];
    var name = data[i][1];
    var status = data[i][4];

    if(!students[roll]){
      students[roll] = {name:name,present:0,total:0};
    }

    students[roll].total++;

    if(status=="Present"){
      students[roll].present++;
    }

  }

  report.clear();
  report.appendRow(["Name","Roll","Present","Total","Percentage"]);

  for(var roll in students){

    var present = students[roll].present;
    var total = students[roll].total;

    var percentage = 0;

    if(total>0){
      percentage = (present/total)*100;
    }

    report.appendRow([
      students[roll].name,
      roll,
      present,
      total,
      percentage
    ]);

  }

}


function updateSubjectReport(){

  var ss = SpreadsheetApp.getActiveSpreadsheet();

  var attendance = ss.getSheetByName("ATTENDANCE");
  var report = ss.getSheetByName("SUBJECT_REPORT");

  var data = attendance.getDataRange().getValues();

  var students = {};

  for(var i=1;i<data.length;i++){

    var roll = data[i][1];
    var name = data[i][2];
    var subject = data[i][3];
    var status = data[i][4];

    if(!students[roll]){
      students[roll] = {
        name:name,
        PRP:{p:0,t:0},
        SS:{p:0,t:0},
        LIC:{p:0,t:0},
        TLW:{p:0,t:0},
        ACS:{p:0,t:0},
        DT:{p:0,t:0}
      };
    }

    students[roll][subject].t++;

    if(status=="Present"){
      students[roll][subject].p++;
    }

  }

  report.clear();
  report.appendRow(["Roll","Name","PRP %","SS %","LIC %","TLW %","ACS %","DT %"]);

  for(var roll in students){

    var s = students[roll];

    function percent(obj){
      if(obj.t==0) return 0;
      return (obj.p/obj.t)*100;
    }

    report.appendRow([
      roll,
      s.name,
      percent(s.PRP),
      percent(s.SS),
      percent(s.LIC),
      percent(s.TLW),
      percent(s.ACS),
      percent(s.DT)
    ]);

  }

}