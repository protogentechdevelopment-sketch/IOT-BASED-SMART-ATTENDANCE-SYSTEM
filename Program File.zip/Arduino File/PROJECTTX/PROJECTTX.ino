#include <SPI.h>
#include <MFRC522.h>

#define SS_PIN 5
#define RST_PIN 22

#define LED_PIN 2
#define BUZZER_PIN 4

MFRC522 rfid(SS_PIN, RST_PIN);

HardwareSerial lora(2);

String studentUID[3] = {
  "1ed21407",
  "71bc1407",
  "4e6b1407"
};

bool present[3] = {false,false,false};

int currentClass = 1;

unsigned long classStart;
int classDuration = 15000;

String lastUID = "";

bool systemStart = false;

void setup(){

Serial.begin(115200);

lora.begin(9600, SERIAL_8N1, 16, 17);

SPI.begin();
rfid.PCD_Init();

pinMode(LED_PIN, OUTPUT);
pinMode(BUZZER_PIN, OUTPUT);

Serial.println("Transmitter Ready");
Serial.println("Waiting for START signal");

}

void loop(){

// Wait for receiver START signal
if(!systemStart){

if(lora.available()){

String msg = lora.readString();
msg.trim();

Serial.print("Received: ");
Serial.println(msg);

if(msg=="START"){

systemStart=true;

Serial.println("System Started");
Serial.println("Class 1 Started");

classBeep();

classStart = millis();

}

}

return;

}

// Stop after class 8
if(currentClass>8){

Serial.println("All Classes Completed");

while(true);

}

// CLASS TIMER
if(millis()-classStart > classDuration){

Serial.print("Class ");
Serial.print(currentClass);
Serial.println(" Finished");

classBeep();

for(int i=0;i<3;i++){

String status="Absent";

if(present[i]) status="Present";

sendData(studentUID[i],status);

present[i]=false;

}

currentClass++;

if(currentClass<=8){

Serial.print("Class ");
Serial.print(currentClass);
Serial.println(" Started");

classBeep();

}

classStart=millis();

lastUID="";

}

// RFID READ

if(!rfid.PICC_IsNewCardPresent()) return;
if(!rfid.PICC_ReadCardSerial()) return;

String uid="";

for(byte i=0;i<rfid.uid.size;i++){

if(rfid.uid.uidByte[i] < 0x10) uid += "0";
uid += String(rfid.uid.uidByte[i],HEX);

}

uid.toLowerCase();

Serial.print("Card UID: ");
Serial.println(uid);

digitalWrite(LED_PIN,HIGH);
digitalWrite(BUZZER_PIN,HIGH);
delay(150);
digitalWrite(LED_PIN,LOW);
digitalWrite(BUZZER_PIN,LOW);

if(uid==lastUID){

rfid.PICC_HaltA();
rfid.PCD_StopCrypto1();
return;

}

lastUID=uid;

bool found=false;

for(int i=0;i<3;i++){

if(uid==studentUID[i]){

present[i]=true;
found=true;

Serial.println("Present Marked");

}

}

if(!found){

Serial.println("Unknown Card");

}

rfid.PICC_HaltA();
rfid.PCD_StopCrypto1();

delay(50);

}

// SEND DATA

void sendData(String uid,String status){

String data = uid + "," + status + "," + String(currentClass);

lora.println(data);

Serial.print("Sent: ");
Serial.println(data);

}

// CLASS BEEP

void classBeep(){

for(int i=0;i<3;i++){

digitalWrite(LED_PIN,HIGH);
digitalWrite(BUZZER_PIN,HIGH);
delay(120);

digitalWrite(LED_PIN,LOW);
digitalWrite(BUZZER_PIN,LOW);
delay(120);

}

}