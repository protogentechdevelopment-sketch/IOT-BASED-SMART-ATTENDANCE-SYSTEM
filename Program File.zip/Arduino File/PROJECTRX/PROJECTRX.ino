#include <WiFi.h>
#include <HTTPClient.h>

#define LED_PIN 2

HardwareSerial lora(2);
HardwareSerial gsm(1);

const char* ssid = "project15";
const char* password = "12345678";

String server="https://script.google.com/macros/s/AKfycbz_SlEtDuN0W-mJbocWOT09lcBMzq6VMbV7WALMe2BbKL2MbpIoTeI6qYoOxmTWKnKXWw/exec";

bool class8Detected=false;
bool smsSent=false;
bool transmitterStarted=false;

unsigned long class8Time=0;

void setup(){

Serial.begin(115200);

pinMode(LED_PIN,OUTPUT);

lora.begin(9600,SERIAL_8N1,16,17);
gsm.begin(9600,SERIAL_8N1,26,27);

WiFi.begin(ssid,password);

Serial.print("Connecting WiFi");

while(WiFi.status()!=WL_CONNECTED){

digitalWrite(LED_PIN,HIGH);
delay(300);
digitalWrite(LED_PIN,LOW);
delay(300);

Serial.print(".");

}

Serial.println(" WiFi Connected");

digitalWrite(LED_PIN,HIGH);

Serial.println("Receiver Ready");

}

void loop(){

static unsigned long lastStart=0;

if(!transmitterStarted){

if(millis()-lastStart>2000){

lora.println("START");
Serial.println("START sent");

lastStart=millis();

}

}

// RECEIVE LORA DATA

if(lora.available()){

transmitterStarted=true;

String data=lora.readStringUntil('\n');
data.trim();

Serial.print("Received: ");
Serial.println(data);

int first=data.indexOf(',');
int second=data.indexOf(',',first+1);

String uid=data.substring(0,first);
String status=data.substring(first+1,second);
String classNum=data.substring(second+1);

Serial.println(uid);
Serial.println(status);
Serial.println(classNum);

String url=server+"?uid="+uid+"&status="+status+"&class="+classNum;

HTTPClient http;

http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
http.begin(url);

int code=http.GET();

if(code>0){

Serial.println("Attendance Updated");

digitalWrite(LED_PIN,LOW);
delay(200);
digitalWrite(LED_PIN,HIGH);

}
else{

Serial.println("Error sending data");

}

http.end();

if(classNum=="8"){

class8Detected=true;
class8Time=millis();

}

}

// AFTER CLASS 8 SEND SMS

if(class8Detected && !smsSent){

if(millis()-class8Time>15000){

Serial.println("Checking Attendance");

checkAttendance();

smsSent=true;
class8Detected=false;

}

}

}

// CHECK ATTENDANCE

void checkAttendance(){

HTTPClient http;

String url = server + "?check=1";

http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);

http.begin(url);

int code = http.GET();

if(code>0){

String response = http.getString();

response.trim();

Serial.print("Script Response: ");
Serial.println(response);

if(response != "OK"){

int start = 0;

while(true){

int end = response.indexOf(';', start);

String entry;

if(end==-1)
entry = response.substring(start);
else
entry = response.substring(start,end);

int c1 = entry.indexOf(',');
int c2 = entry.indexOf(',',c1+1);

String name = entry.substring(0,c1);
String phone = entry.substring(c1+1,c2);
String percent = entry.substring(c2+1);

String message = "Dear Parent, "+name+"'s attendance is "+percent+"%. Please maintain above 75%.";

sendSMS(phone,message);

if(end==-1) break;

start = end+1;

delay(5000);

}

}

}

else{

Serial.println("Error checking attendance");

}

http.end();

}

// SEND SMS

void sendSMS(String number,String message){

Serial.print("Sending SMS to: ");
Serial.println(number);

gsm.println("AT");
delay(1000);

gsm.println("AT+CMGF=1");
delay(1000);

gsm.print("AT+CMGS=\"");
gsm.print(number);
gsm.println("\"");

delay(1000);

gsm.print(message);

gsm.write(26);

delay(5000);

Serial.println("SMS Sent");

}